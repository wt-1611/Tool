#!/bin/bash

filee=$1

[ ! -d /tmp/${1}_n ] && mkdir /tmp/${1}_n 
cd /tmp/${1}_n

ca(){
chronyc sources 1> t 2>/dev/null
ser=chronyd
s=`cat t| egrep -wv 'Number|Poll|=' | grep '\^' | awk '{print $2}'`
rem='<br>'
for i in $s;do
	re=$(echo -e $(echo  $i)$rem$re)
done


c=`cat t| egrep -wv 'Number|Poll|=' | grep '\^\*' | awk '{print $2}'`
if [ `echo $c|wc -w` -eq 0 ];then
        wp="<font color='red'>false</font>"
else
        wp="<font color='green'>sussess</font>"
fi
st=`cat t| egrep -wv 'Number|Poll|=' | grep '\^\*' | awk '{print $3}'`
time_s=`cat t| egrep -wv 'Number|Poll|=' | grep '\^\*' | awk '{print $4}'`
#last_s=`cat t| egrep -wv 'Number|Poll|=' | grep '\^\*' | awk '{print $6}'`
offset=`cat t| egrep -wv 'Number|Poll|=' | grep '\^\*' | awk -F'[' '{print $2}'   | awk -F ']' '{print $1}' | sed 's/[[:space:]]*//g'`
}


cn(){
ntpq -p 1> t 2>/dev/null
ser=ntpd
s=`cat t  | egrep -vw 'refid|=' | sed 's/^.//g' | awk '{print $1}'`
rem='<br>'
for i in $s;do
        re=$(echo -e $(echo  $i)$rem$re)
done

c=`cat t  | egrep -vw 'refid|=' | grep '\*'| sed 's/^.//g'|awk '{print $1}'`
if [ `echo $c|wc -w` -eq 0 ];then
        wp="<font color='red'>false</font>"
else    
        wp="<font color='green'>sussess</font>"
fi

st=`cat t  | egrep -vw 'refid|=' | grep '\*'| awk '{print $3}'`
time_s=`cat t  | egrep -vw 'refid|=' | grep '\*'| awk '{print $6}'`
#last_s=`cat t  | egrep -vw 'refid|=' | grep '\*'| awk '{print $8}'`
offset=`cat t  | egrep -vw 'refid|=' | grep '\*'| awk '{print $9}'`
}

cre(){
cat > $filee << eof
 <tr>
    <td>`echo $wp`</td>
    <td>$filee</td>
    <td>`echo $ser`</td>
    <td>$re</td>
    <td>`echo $c`</td>
    <td>`echo $st`</td>
    <td>`echo $time_s`</td>
    <td>`echo $offset`</td>
 </tr>
eof
}


c=`netstat  -upln | grep chron[y] | wc -l`
n=`netstat  -upln | grep  ntp[d] | wc -l`

if [ ! $c -eq 0 ];then
	ca
	cre
elif [ ! $n -eq 0 ];then
	cn
	cre
else
nu=`echo null`
cat > $filee << eof
 <tr>
    <td>`echo "<font color='red'>false</font>"`</td>
    <td>$filee</td>
    <td>未配置时间服务</td>
    <td>$nu</td>
    <td>$nu</td>
    <td>$nu</td>
    <td>$nu</td>
    <td>$nu</td>
 </tr>
eof

fi
[ -f t ] && rm -fr t
exit 0
