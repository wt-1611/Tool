#!/bin/bash
p='\n'
for i in `ls -1 /tmp/remote_ace_wt`;do
	ip=$(echo -e $(ls -1 /tmp/remote_ace_wt/$i/tmp/${i}_n)$p$ip)
done

cat > c.html <<eof
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>时间源</title>
<style type="text/css">
#myInput {
    background-image: url('https://static.runoob.com/images/mix/searchicon.png'); /* 搜索按钮 */
    background-position: 10px 12px; /* 定位搜索按钮 */
    background-repeat: no-repeat; /* 不重复图片 */
    width: 100%;
    font-size: 16px;
    padding: 12px 20px 12px 40px;
    border: 1px solid #ddd;
    margin-bottom: 12px; 
}
 
#myTable {
    border-collapse: collapse; 
    width: 100%; 
    border: 1px solid #ddd;
    font-size: 18px; 
}
 
#myTable th, #myTable td {
    text-align: left;
    padding: 12px;
}
 
#myTable tr {
    /* 表格添加边框 */
    border-bottom: 1px solid #ddd; 
}
 
#myTable tr.header, #myTable tr:hover {
    /* 表头及鼠标移动过 tr 时添加背景 */
    background-color: #f1f1f1;
}
</style>
<script type="text/javascript">
	function ApplyStyle(s){
		document.getElementById("mytab").className=s.innerText;
	}

</script>
<script> 
	function myFunction() {
  // 声明变量
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
 
  // 循环表格每一行，查找匹配项
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
} 
 window.onload = displayTime; 
</script>
</head>
 
<body>
<div class="title">
	<table><tr><td>
		<input type="text" id="myInput" onkeyup="myFunction()" placeholder="搜索...">
	</td></tr></table>
</div>
<table id="myTable">
	<tr class="header">
    <th>同步状态</th>
    <th>检测主机</th>
    <th>时间源服务</th>
    <th>同步时钟源</th>
    <th>正在同步的时钟源</th>
    <th>同步的时钟源层级</th>
    <th>同步周期(s)</th>
    <th>延迟(s)</th>
  </tr>
eof

for c in $ip;do
	 cat /tmp/remote_ace_wt/$c/tmp/${c}_n/$c >>c.html
done 

cat >> c.html <<eof
</table>

</body>
</html>
eof

[ -d /tmp/remote ] && rm -fr /tmp/remote_ace_wt/*
